﻿PixelMplus（ピクセル・エムプラス）
=================================

Copyright (C) 2002-2013 M+ FONTS PROJECT



Description
-----------

8bit風味のファミコンのビットマップフォントのような感じを出せる
TrueTyep アウトラインフォントです。


Feature
-------

- ビットマップフォントのように見えるが、アウトラインのみのTrueTypeフォント。
  埋め込みビットマップは なし。ボールド体（太字）あり。

- JIS第1・第2水準のすべての漢字を収録。ISO-8859-1(Latin-1)の文字も収録。
  そのほかにもいくつかの記号を追加。

- 実体は単なるTrueType等幅フォント。テキストエディターで使用することもできる。

- ライセンスは自由なM+ FONT LICENSE。


詳しくは以下を参照。
http://itouhiro.hatenablog.com/entry/20130602/font



License
-------

M+ FONT LICENSE

M+ FONT LICENSEについては、配布物に含まれる
mplus_bitmap_fonts/LICENSE_E
をご覧ください。


-- 
Itou Hiroki <itouhiro at users dot sourceforge dot jp>
